# Spotify main page with tailwind css

A Pen created on CodePen.io. Original URL: [https://codepen.io/vip69fun/pen/MWBbRde](https://codepen.io/vip69fun/pen/MWBbRde).

